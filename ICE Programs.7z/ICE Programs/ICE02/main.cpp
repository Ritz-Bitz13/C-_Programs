/* 
 * File:   main.cpp
 * Author: Martin Barber
 * Student ID: 100368442
 * Created on January 20th, 2022, 7:40 p.m.
 * Purpose: OOP 2200 Week 2 - ICE02 - Fundamentals Activities
 * Definition: Input numbers, verify numbers have been entered and make a chart multiplying the numbers from 1 - 10
 */

#include <iostream>
#include <iomanip>

using namespace std;

// What to do for assignment:
//1) Accept two numbers as input from the user
//1.5) Validate both numbers
//2) Use a loop to ensure nothing happens until a number has been entered
//3) Once a good number has been recieved, output the value of 1 - 10 x each number of the input
//example: input 5 and 7
//output:  -      5      7
//         1      5      7
//         2      10     14 etc to 10

/*
 * Main Program
 */
int main() {
    // Set the Variables needed
    int Num1, Num2;
    cout << "Please enter your first number: "; //First prompt User
    cin >> Num1; // Recieve input from user
    
    // Test to see if the number is actually a number and nothing else
    while (cin.fail()) {
        cin.clear(); // clears the status state of cin
        cin.sync(); // clears the input buffer
        cout << "That was not an integer, please enter your first number: ";
        cin >> Num1;
    }
    
    // Recieve second number
    cout << "Please enter your second number: "; // Second prompt to the User
    cin >> Num2; // Recieve input from user
    
    // Test to see if the number is actually a number and nothing else
    while (cin.fail()) {
        cin.clear(); // clears the status state of cin
        cin.sync(); // clears the input buffer
        cout << "That was not an integer, please enter your second number: ";
        cin >> Num2;
    }
    
    // Like to leave a space for the start of the program so you can focus on the main information being shown
    cout << endl;
    
    // Once Both numbers check their check/verification, start making the chart
 
    cout << setw(8) << "" << setw(15) << "Number 1" << setw(15) << "Number 2" << endl;
    cout << setw(8) << "--" << setw(15) << Num1 << setw(15) << Num2 << endl;
    // Added a spacer between the numbers given and where the math begins. Looks cleaner to me
    cout << endl;
    
    // Use For loop to get the numbers 1 to 10 to multiply them by the input numbers
    for (int numberCount = 1; numberCount <=10; numberCount++){
        //               multiply number             mult number * Num1         s     mult number * Num2
        cout << setw(8) << numberCount << setw(15) << numberCount*Num1 << setw(15) << numberCount*Num2 << endl;
    }
    // Like to leave a space to the program doesn't seem crushed by info without space to see what the main output is
    cout << endl;

    return 0;
}

