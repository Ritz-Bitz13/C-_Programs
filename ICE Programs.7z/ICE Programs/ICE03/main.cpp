//<editor-fold desc="Comment Header">
/* 
 * File:   main.cpp
 * Author: Martin Barber
 * Student ID: 100368442
 * Created on Feb 3, 2022, 7:53 p.m.
 * Purpose: OOP 2200 Week 4 - ICE 04
 * Definition: Create a function that divides two numbers and outputs them
 */
//</editor-fold>

//<editor-fold desc="Inclusions and Global Variables">
#include <iostream>
using namespace std;
//</editor-fold>

//<editor-fold desc="Function Template">
template <class T>
T divide(T num1, T num2){
    if (num2 == 0)
        return 0;
    else
        return num1 / num2;
}
using namespace std;
//</editor-fold>

/*
 * Main Function
 */
int main() {
    
    //<editor-fold desc="Main function">
    // Introduction for the screen
    cout << "Ice 04 - Functions / Templates" << endl;
    cout << "==================" << endl;
    
    // outputs for each of the questions to feed into the template and give the answer. int or double, does not matter.
    cout << "8 / 4 =       " << divide(8.0,4.0) << endl;
    cout << "----------------------" << endl;
    cout << "45.1 / 7.2 =  " << divide(45.1,7.2) << endl;
    cout << "----------------------" << endl;
    cout << "-10.0 / 3 =   " << divide(-10.0,3.0) << endl;
    cout << "----------------------" << endl;
    cout << "9.56 / 3.12 = " << divide(9.56,3.12) << endl;
    cout << "----------------------" << endl;
    cout << "12 / 0 =      " << divide(12.0,0.0) << endl;
    cout << "----------------------" << endl;
    //</editor-fold>

    return 0;
}

