//<editor-fold desc="Comment Header">
/* 
 * File:   Lab5_Group1.h
 * Author: Jake
 * Author: Martin
 *
 * Created on April 5, 2022, 4:03 PM
 */
//</editor-fold>

//<editor-fold desc="Include">
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
namespace Lab5 {

#ifndef LAB5_GROUP1_H
#define LAB5_GROUP1_H
//</editor-fold>
    
//<editor-fold desc="ReadDouble">
double ReadDouble(const double MINIMUM, const double MAXIMUM) {
    bool IsNumeric(string);  // function prototype
    bool notADbl = true; // set value to true until proven false to pass the check
    string str;
    
    while (notADbl) {
        try {
            cin >> str;  // accept a string input
            if (!IsNumeric(str)) throw str; // If it is not numeric, throw it away
            
            if (atof(str.c_str()) < MINIMUM || atof(str.c_str()) > MAXIMUM) throw atof(str.c_str()); // if it is not in the range, throw it away
        }
        catch (string e) {
            cout << "\"" << e << "\"" <<" is not numeric. Please try again and enter a numeric value: "; // Show the error and state it isnt numeric, ask for a new input
            continue;
        }   
        catch (double ee) {
            cout << "\"" << ee << "\"" <<" is out of range. Please try again and enter a value between -99.9 and 99.9: "; // Show the error and state it is out of range, ask for a new input
            continue;
        }
        notADbl = false; // if notadbl is false, it means the input is proper. meets all the criteria
    }
    
    return atof(str.c_str()); // converts to an double 
    // Table 14.7 - Page 650 of textbook
}
//</editor-fold>
 
//<editor-fold desc="IsNumeric">
bool IsNumeric(string str) {
    int start = 0, i, strLen;
    bool isValid = true;        // assume valid at first
    bool hasSign = false;       // assume positive number first (no - sign)
    bool hasDecimal = false;    // assume there is no decimal place
    strLen = int(str.length());
    
    // check for an empty string
    if (strLen == 0) isValid = false;
    
    // check for a leading sign
    if (str.at(0) == '-' || str.at(0) == '+') {
        hasSign = true;
        start = 1;  // skip the first character and check rest for integer status
    }
    
    // check there is one char after sign (if a sign exists)
    if (hasSign && strLen == 1) isValid = false;
    
    // now iterate through string for numeric values.
    i = start;  // set loop to start at character 0 or 1, based on hasSign

 

    while (isValid && i < strLen){
        if (str.at(i) == '.') { 
            if (hasDecimal) isValid = false;
            hasDecimal = true;
        } 
        else {
            if (!isdigit(str.at(i))) isValid = false; 
        }
        i++;
    }
    
    return isValid;
}
//</editor-fold>

}
#endif /* LAB5_GROUP1_H */