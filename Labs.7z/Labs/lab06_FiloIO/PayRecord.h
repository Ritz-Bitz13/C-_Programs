#ifndef PAYRECORD_H
#define PAYRECORD_H
#include <vector>
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

//<editor-fold desc="PayRecord Struct">

struct PayRecord {
    
    string Fname;
    string Lname;
    double HoursWorked;
    double HourlyWage;   
};

PayRecord CreateRecord (string fName, string lName, double hoursWorked, double hourlyWage) {
    PayRecord record;
    
    record.Fname = fName;
    record.Lname = lName;
    record.HoursWorked = hoursWorked;
    record.HourlyWage = hourlyWage;
    
    return record;
}

bool WriteToFile(vector<PayRecord> records, string filename){
    ofstream oFile; //output stream
    oFile.open(filename.c_str()); // requires the c_str() array for open, not writing

    if (oFile.fail()) return false;

    for (PayRecord record: records){
        // output to the file
        oFile   << record.Fname << " " // rather than cout, we are printing to the file
                << record.Lname << " "
                << record.HoursWorked << " "
                << record.HourlyWage << " "
                << endl;
    }
    oFile.close();
    return true;
    
    
    
    
}



/*
Car CreateCar(int carID, HondaModel model, Version version, string color,
        int manuYear, int manuMonth, int manuDay) {
    Car car;
    
    car.CarID = carID;
    car.Model = model;
    car.Version = version;
    car.Color = color;
    car.ManuYear = manuYear;
    car.ManuMonth = manuMonth;
    car.ManuDay = manuDay;
    
    return car;
} */



//</editor-fold>

#endif /* PAYRECORD_H */
