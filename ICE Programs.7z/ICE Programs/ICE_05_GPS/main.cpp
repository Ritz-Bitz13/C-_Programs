//<editor-fold desc="Comment Header">
/* 
 * File:   main.cpp
 * Author: Martin Barber
 * Student ID: 100368442
 * Created on February 17, 2022, 7:22 p.m.
 * Purpose: OOP 2200 ICE 05: GPS co-ordinites
 * Definition: Create GPS co-ordinates in a class
 */
//</editor-fold>


#include <iostream>
#include "GPS.h"
using namespace std;

/*
 * 
 */
int main() {
    
    GPS location1;
    GPS location2;
    
    location1.setGPS("Canada", 67.7789, 23.7685);
    
    location2.setLocation("United State of America");
    location2.setLatitude(78.8643);
    location2.setLongitude(45.7786);
    
    cout << location1.showGPSLocation() << endl;
    
    cout << location2.showGPSLocation() << endl;
    
    

    return 0;
}

