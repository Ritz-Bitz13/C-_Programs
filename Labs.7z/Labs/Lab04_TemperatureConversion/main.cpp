//<editor-fold desc="Comment Header">
/* 
 * File:   main.cpp
 * Author: Martin Barber
 * Student ID: 100368442
 * Created on March 20, 2022, 11:08 a.m.
 * Purpose: OOP 2200 Lab 4: Arrays / Pointers
 * Definition: Get the user to input the number of days to enter a temperature and then convert the temperature.
 */
//</editor-fold>


#include <iostream>
#include <iomanip>
#include "GetInput.h"
using namespace std;


double FahConvert(double celsius)
{
    double converted;
    converted = ((celsius * (9.0/5.0)) +32.0);
    return converted;
}

const int MaxDays = 365;

/*
 * Main Function
 */
int main() {

    double Temperature[MaxDays];
    int     DaysForArray;
    int checkNumber = 0;
    double tempNum;
    bool temp = true;
    
    
    
    cout << "\nHow many days would you like to enter? ";
    checkNumber = GetAnInt();
    cin.sync();


    // While you're outside the range of days you can enter, keep looping until you get a good answer
    while (checkNumber <=0 || checkNumber >365)
    {
        cout << "please enter a number between 1 and 365: ";
        checkNumber = GetAnInt();
        cin.sync();
    }
    
    DaysForArray = checkNumber; // set the nuber of days you want to enter into the array.
    
    cout << "\nTEMPERATURE REPORTER\n" << string(20, '=') << endl;
    for (int i = 0; i < DaysForArray; i++) 
    {
        do{
            cout << "Celsius temperature for day " << i+1 << ": "; // getting the input of each temperature per day
            tempNum = GetADbl();
        
            if (tempNum >= -90 && tempNum <= 60) // if the temperature is outside the range, fail it and ask for a different answer
            {
                Temperature[i] = tempNum; // set the number into the array to store a number
                temp = true;
            }
            else
            {
                cout << "Temperature out of range! Coldest: -89.2"<<char(248)<<"C, Hottest: 57.8"<<char(248)<<"C. Try again.\n"; // out of range, fail the check and loop back to try and get another input
                temp = false;
            }
        }while (!temp);
    }
    
    // set a loop to use the function to calculate the converted temperatures.
    for (int i = 0; i < DaysForArray; i++)
    {
        cout    << "Day " << i+1 << setw(10)
                << Temperature[i]<<char(248)<<"C" << setw(10)
                << FahConvert(Temperature[i]) <<char(248)<<"F" << endl;
    }
    
    return 0;
}
