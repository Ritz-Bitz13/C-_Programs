//<editor-fold desc="Comment Header">
/* 
 * File:   Boxes.h
 * Author: Martin Barber
 * Student ID: 100368442
 * Created on March 13th, 2022, 1:56 p.m.
 * Purpose: OOP 2200 Week 08
 * Definition: Boxes for shipping
 */
//</editor-fold>

#ifndef BOXES_H
#define BOXES_H
using namespace std;

class Boxes
{
private:
    double _length;
    double _width;
    double _height;
    double _volume;
    
public:
    
    // Constructor Prototypes
    Boxes();
    Boxes(double, double, double);
    
    //Set Mutators
    void setLength(double);
    void setWidth(double);
    void setHeight(double);
    
    
    void setBoxes(double, double, double);
    // Get Accessors
    double getLength();
    double getWidth();
    double getHeight();
    
    
    string showBoxDimentions();
    double showBoxVolume();
};
    
//<editor-fold desc="Constructors">
//Default Constructor
Boxes::Boxes(){
    setLength(1.0);
    setWidth(1.0);
    setHeight(1.0);
    
    

}; //if you have anything in here, its defaults!!!!

// Input Constructor
Boxes::Boxes(double length, double width, double height)
{
    setLength(length);
    setWidth(width);
    setHeight(height);    // These are the void statements, delete the void and change variable name to the variables in parameter above.
}
//</editor-fold>

//<editor-fold desc="Mutators">

void Boxes::setLength (double length)
{
    if (length >=0.0)
        _length = length;
}

void Boxes::setWidth(double width)
{
    if (width >=0.0)
        _width = width;
}
void Boxes::setHeight(double height)
{
    if (height >=0.0)
        _height = height;
}

void Boxes::setBoxes(double length, double width, double height)
{
    setLength(length);
    setWidth(width);
    setHeight(height);
}

//</editor-fold>
    
    //<editor-fold desc="Accessors">

double Boxes::getLength()
{
    return _length; 
}
double Boxes::getWidth()
{
    return _width; 
}
double Boxes::getHeight()
{
    return _height;
}


string Boxes::showBoxDimentions()
{
    string retVal = "\nPackage Details\n******************\n";
    retVal += "Length: " + to_string(_length);
    retVal += "\nWidth: " + to_string(_width);
    retVal += "\nHeight: " + to_string(_height);
    retVal += "\nVolume: " + to_string(_length * _width * _height);
    
    return retVal;
}
    
//</editor-fold>



#endif /* BOXES_H */

