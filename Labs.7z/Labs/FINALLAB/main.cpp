/* 
 * File:   main.cpp
 * Author: Jake
 *
 * Created on April 14, 2022, 7:43 PM
 */

#include <iostream>
#include <fstream>  // File tools
#include <cstdlib>
#include <valarray>  // For exit method
#include <iomanip>
#include <vector>
#include "PayRecord.h"

using namespace std;
double total;
string fname;
string lname;
string fullname;

void ShowOutput(vector<PayRecord> records){
    cout << "Jacob & Martin" << endl;
    cout << "PAY FOR THE WEEK" << endl;
    //cout << string(30,"-") + "\n\n";
    
    // table Contents
    for (PayRecord record: records) {
        fname = record.Fname.at(0);
        lname = record.Lname;
        fullname = fname + ". " + lname;
        cout << right << setw(20) << fullname 
            << setw(3) << "$" 
            << setw(10) << (record.HoursWorked * record.HourlyWage)
            << "\n"; 
    }
    cout << string(30,'=') + "\n";
    cout << setw(10) << total;
    cout << endl << endl;
 
    return;
}
/*
 * 
 */
int main() {

    vector<PayRecord> records;
    string inputString;
    const int MAXFIELDS = 4;
    string fields[MAXFIELDS];
    int index = 0, counter = 0; // index is for fields, counter for rows
    
    // now let us open the file
    ifstream myFile;
    myFile.open("hours.txt");
    // test if open success
    if (myFile.fail()) {
        cout << "File failed to open!\n\n";
        exit(1);
    }
    
    cout << "Trying to read from the file...\n";
    
    getline(myFile, inputString, '\n');
    cout << "Got line: " << inputString << endl;
    
    while(myFile.good()) {
        // looping for each line of the file
        counter++;
       
        for (int i = 0; i < inputString.length(); i++) {
            if (inputString[i] == ' ') {
                index++;
                continue;
            }
            fields[index] += inputString[i];
        }
        
        // to take the array of fields and populate the struct instance
        try {
            PayRecord record;
            record.Fname = fields[0];
            record.Lname = fields[1];
            record.HoursWorked = atof(fields[2].c_str());
            record.HourlyWage = atof(fields[3].c_str());
            
            total += record.HoursWorked * record.HourlyWage;
            
            records.push_back(record);
        }
        catch (exception e) {
            cerr << "Error Occurred: " << e.what() << endl << endl;
        } 
        
        // reset things for the next record
        for (int i = 0; i < MAXFIELDS; i++) fields[i] = "";
        index = 0;
        
        getline(myFile, inputString, '\n');
        cout << "Got Line: " << inputString << endl;
    }
    ShowOutput(records);
    myFile.close();  
    
       // write to a new file
    if(WriteToFile(records, "Pay.txt")) {
        cout << "Write was successful :) ! " << endl << endl;
    }
    else cout << "Write failed :( ! " << endl << endl;
       
    return 0;
}

