//<editor-fold desc="Comment Header">
/* 
 * File:   main.cpp
 * Author: Martin Barber
 * Student ID: 100368442
 * Created on February 17, 2022, 7:22 p.m.
 * Purpose: OOP 2200 ICE 06: GPS coordinites
 */
//</editor-fold>


#ifndef GPS_H
#define GPS_H
using namespace std;

class GPS
{
private:
    string _location;
    double _latitude;
    double _longitude;
    
    
public:
    // Constructors ProtoTypes
    GPS();
    GPS(string, double, double);
    
    //Set Mutators
    void setLocation(string);
    void setLatitude(double);
    void setLongitude(double);
    
    void setGPS (string, double, double);
    
    
    // Get Accessors
    string getLocation();
    double getLatitude();
    double getLongitude();
    
    string showGPSLocation();
};


//Default Constructor
GPS::GPS(){
    
}

// Input Constructor
GPS::GPS(string location, double latitude, double longitude)
{
    setLocation(location);
    setLatitude(latitude);
    setLongitude(longitude);
}
    
void GPS::setLocation (string location)
{
    if (location.length() > 0)
    {
        _location = location;
    }      
}
void GPS::setLatitude(double latitude)
{
    if (latitude < -90 || latitude > 90)
    {
        throw out_of_range("Latitude Range must be between -90 and 90");
    }
    else
    {
        _latitude = latitude;
    }
        
}

void GPS::setLongitude(double longitude)
{
    if (longitude < -180 || longitude > 180)
    {
        throw out_of_range("Longitude Range must be between -180 and 180");
    }
    else
    {
        _longitude = longitude;
    }
        
}

void GPS::setGPS (string location, double latitude, double longitude)
{
    setLocation(location);
    setLatitude(latitude);
    setLongitude(longitude);
}


//Accessors
string GPS::getLocation()
{
    return _location;
}
double GPS::getLatitude()
{
    return _latitude;
}
double GPS::getLongitude()
{
    return _longitude;
}

string GPS::showGPSLocation()
{
    string retVal = "My GPS Co-Ordinates\n*****************************\n";
    retVal += getLocation() + "\n";
    retVal += "Latitude: " + to_string(getLatitude()) + "\n";
    retVal += "Longitude: " + to_string(getLongitude());

    return retVal;
}


// Custom Methods


#endif /* GPS_H */

