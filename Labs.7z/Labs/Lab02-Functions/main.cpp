//<editor-fold desc="Comment Header">
/* 
 * File:   main.cpp
 * Author: Martin Barber
 * Student ID: 100368442
 * Created on February 5, 2022, 3:02 p.m.
 * Purpose: OOP 2200 Week 5 - Lab 2 - Functions GPA Calculator 
 * Definition: Create a program that will use the function GradePoints() to get a GPA from a Grade number.
 */
//</editor-fold>

//<editor-fold desc="Inclusions and Global Variables">
#include <iostream>
#include <iomanip>
#include <cmath>
#include <windows.h>
using namespace std;

HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
double gradeInput;
double pointsGrade;
//</editor-fold>

//<editor-fold desc="Function Gradepoints">
double GradePoints(double n){
    if (round(n) < 50)
        return 0;
    else if (round(n) < 55)
        return 1;
    else if (round(n) < 60)
        return 1.5;
    else if (round(n) < 65)
        return 2.0;
    else if (round(n) < 70)
        return 2.5;
    else if (round(n) < 75)
        return 3.0;
    else if (round(n) < 80)
        return 3.5;
    else if (round(n) < 85)
        return 4.0;
    else if (round(n) < 90)
        return 4.5;
    else
        return 5.0;
}
//</editor-fold>

//<editor-fold desc="Main Program">
/*
 * Main Program
 */
int main() {

    //ask the user to give a percentage to convert or press -1 to exit the program.
    cout << "Please enter percentage grade to convert to grade points. Enter '-1' to quit" << endl << endl;
    // The program will stay in the loop until the user types in -1 to end the program
    while (gradeInput != -1){
        // ask for users input
        cout << "Enter percentage here: ";
        // set text colour to gold to identify it easier for the user
        SetConsoleTextAttribute(hConsole, 6);
        cin >> gradeInput; // user input
        // set text colour back to default
        SetConsoleTextAttribute(hConsole, 7);
        // checks to see if input is -1, if it is, skip the fail check and end the program.
        if (gradeInput != -1)
        {
            // If user types in a string it will fail, any number less than -1 or anything great than 100 it will ask the user for a new input
            while (cin.fail() || gradeInput < 0 || gradeInput > 100) {
                cin.clear(); // Clears the Status of cin.fail
                cin.sync(); // clears the input buffer
                cout << "You can only have the number between 0 and 100, please try again: ";
                //Change text colour to orange to highlight the importance of the number
                SetConsoleTextAttribute(hConsole, 6);
                // ask again for the input because of the fail
                cin >> gradeInput;
                //reset to default text colour
                SetConsoleTextAttribute(hConsole, 7);
            }


            SetConsoleTextAttribute(hConsole, 10);
            cout << endl;
            // output to display the GPA
            cout << round(gradeInput) << ".0% is " << GradePoints(gradeInput) << " grade points." << endl << endl;
            SetConsoleTextAttribute(hConsole, 7);
        }
    }
    // Say goodbye
    SetConsoleTextAttribute(hConsole, 12);
    cout << endl << "Goodbye" << endl << endl;
    SetConsoleTextAttribute(hConsole, 7);
    
    return 0;
}
//</editor-fold>


