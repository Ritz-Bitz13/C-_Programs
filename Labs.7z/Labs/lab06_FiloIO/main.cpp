
/* 
 * File:   main.cpp
 * Author: Jake
 *
 * Created on April 14, 2022, 7:43 PM
 */

//<editor-fold desc="Inclusions and Global Variables">
#include <iostream>
#include <fstream> // file tools
#include <cstdlib>
#include <valarray> // for the exit method
#include "PayRecord.h"
#include <iomanip>
#include <vector>
using namespace std;
//</editor-fold>

void ShowOutput(vector<PayRecord> records){
    cout << string(44,'-') + "\n\n";
    // Table Header:
    cout << setw(3) << "ID" 
            << setw(10) << "Model"
            << setw(10) << "Version"
            << setw(10) << "Version"
            << string(44,'-') << "\n";
    // table Contents
    for (PayRecord record: records) {
        cout << setw(3) << record.Fname 
            << setw(3) << record.Lname 
            << setw(3) << record.HoursWorked 
            << setw(3) << record.HourlyWage << "\n"; 
    } 
    
    cout << endl << endl;
 
}

/*
 * 
 */
int main() {

    vector<PayRecord> records;
    string inputString;
    const int MAXFIELDS = 4;
    string fields[MAXFIELDS];
    int index = 0, counter = 0; // index is for fields, counter for rows
    
    // now let us open the file
    ifstream myFile;
    myFile.open("hours.txt");
    // test if open success
    if (myFile.fail()) {
        cout << "File failed to open!\n\n";
        exit(1);
    }
    
    cout << "Trying to read from the file...\n";
    
    getline(myFile, inputString, '\n');
    cout << "Got line: " << inputString << endl;
    
    while(myFile.good()) {
        // looping for each line of the file
        counter++;
       
        for (int i = 0; i < inputString.length(); i++) {
            if (inputString[i] == ' ') {
                index++;
                continue;
            }
            fields[index] += inputString[i];
        }
    
        
        // to take the array of fields and populate the struct instance
        try {
            PayRecord record;
            record.Fname = fields[0];
            record.Lname = fields[1];
            record.HoursWorked = atof(fields[2].c_str());
            record.HourlyWage = atof(fields[3].c_str());
            
            
            records.push_back(record);
        }
        catch (exception e) {
            cerr << "Error Occurred: " << e.what() << endl << endl;
        } 
        
        // reset things for the next record
        for (int i = 0; i < MAXFIELDS; i++) fields[i] = "";
        index = 0;
        
        getline(myFile, inputString, '\n');
        cout << "Got Line: " << inputString << endl;
    }
    ShowOutput(records);
    myFile.close();  
    
       // write to a new file
    if(WriteToFile(records, "Pay.txt")) {
        cout << "Write was successful :) ! " << endl << endl;
    }
    else cout << "Write failed :( ! " << endl << endl;
       
    return 0;
}