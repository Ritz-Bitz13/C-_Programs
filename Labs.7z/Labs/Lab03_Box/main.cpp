//<editor-fold desc="Comment Header">
/* 
 * File:   main.cpp
 * Author: Martin Barber
 * Student ID: 100368442
 * Created on March 10, 2022, 7:28 p.m.
 * Purpose: OOP 2200 Week 8 - Lab3 Packing Box
 * Definition: This lab will create a package that will have 
 */
//</editor-fold>

//<editor-fold desc="Inclusions and Global Variables">

#include <iostream>
#include "boxes.h"
#include "GetInput.h"
using namespace std;
//</editor-fold>

/*
 * 
 */
int main() {
    bool change = true;
    
    double boxLength;
    double boxWidth;
    double boxHeight;
    
    Boxes box1(5.05, 5.23, 5.55);
    
    cout << box1.showBoxDimentions() << endl;
    
    Boxes box2; // Make the user input the second box
    
    cout << "\nPlease enter your next box Length: ";
    boxLength = GetADbl();
    cin.sync(); // clears the input buffer
    box2.setLength(boxLength); // Sets length of box2 to the input
    
    cout << "\nPlease enter the box Width: ";
    boxWidth = GetADbl();
    cin.sync(); // clears the input buffer
    box2.setWidth(boxWidth);
   
    cout << "\nPlease enter the box Height: ";
    boxHeight = GetADbl();
    cin.sync(); // clears the input buffer
    box2.setHeight(boxHeight);
    cout << box2.showBoxDimentions() << endl;

    string input;
    int box;
    do{
        cout << "\nWould you like to change box1 dimentions or box2 dimentions? Y or N: "; // if yes, you will go to next question, if no, the program will end.
        cin >> input;
        if (input == "y" || input == "Y")
        {
            cout << "\nWould you like to change box: 1 or 2? "; // would you like to edit a box that is in the system
            box = GetAnInt(); // get input
            if (box == 1)
            {
                // Getting the Length input of the first box
                cout << "\nPlease enter the new box1 Length: ";
                boxLength = GetADbl();
                cin.sync(); // clears the input buffer
                box1.setLength(boxLength); // Sets length of box2 to the input
                
                // Getting the Width input of the first box
                cout << "\nPlease enter the new box1 Width: ";
                boxWidth = GetADbl();
                cin.sync(); // clears the input buffer
                box1.setWidth(boxWidth);
                
                // Getting the Height input of the first box
                cout << "\nPlease enter the box1 Height: ";
                boxHeight = GetADbl();
                cin.sync(); // clears the input buffer
                box1.setHeight(boxHeight);
                cout << box1.showBoxDimentions() << endl;
                
            }
            else if (box == 2)
            {
                // Getting the Length input of the 2nd box
                cout << "\nPlease enter the new box2 Length: ";
                boxLength = GetADbl();
                cin.sync(); // clears the input buffer
                box2.setLength(boxLength); // Sets length of box2 to the input
                
                // Getting the Width input of the 2nd box
                cout << "\nPlease enter the new box2 Width: ";
                boxWidth = GetADbl();
                cin.sync(); // clears the input buffer
                box2.setWidth(boxWidth);
                
                // Getting the Height input of the 2nd box
                cout << "\nPlease enter the box2 Height: ";
                boxHeight = GetADbl();
                cin.sync(); // clears the input buffer
                box2.setHeight(boxHeight);
                cout << box2.showBoxDimentions() << endl;
                
            }
            else if (box == -1) // user asked to exit.
            {
                change = false; // Change the variable to false to end the loop
            }
            else
                cout << "Unknown box. Please try again or type -1 to exit.";
        }
        else if (input == "n" || input == "N")
        {
            change = false;
            cout << "Have a great day!\n"; // User asked to leave.
        }
        else
            cout << "Unknown input - Please try again."; // User did not enter Y or N.
    }while (change == true); // continue while change is true.
    
    
    
    
    
    
    return 0;
}

