
//<editor-fold desc="Comment Header">
/* 
 * File:   main.cpp
 * Author: Martin Barber
 * Student ID: 100368442
 * Created on March 17, 2022, 7:28 p.m.
 * Purpose: OOP 2200 Week 8 - Card deck
 * Definition: 
 */
//</editor-fold>

#include <iostream>
#include <iomanip>
#include "MyArrayTemplates.h"

using namespace std;
using namespace MyArrayTemplates;

int GetRandomNumber(int min, int max)
    {
        return rand() % (max - min + 1) + min;
    }
/*
 * Main Function
 */
int main() {
    srand(time(NULL));
    int card_pick;
    int count = 0;

    const int CARDS = 52;
    
    string cardDeck[CARDS] = {  "A_H", "2_H", "3_H", "4_H", "5_H", "6_H", "7_H", "8_H", "9_H", "10_H", "J_H", "Q_H", "K_H",
                                "A_D", "2_D", "3_D", "4_D", "5_D", "6_D", "7_D", "8_D", "9_D", "10_D", "J_D", "Q_D", "K_D",
                                "A_C", "2_C", "3_C", "4_C", "5_C", "6_C", "7_C", "8_C", "9_C", "10_C", "J_C", "Q_C", "K_C",
                                "A_S", "2_S", "3_S", "4_S", "5_S", "6_S", "7_S", "8_S", "9_S", "10_S", "J_S", "Q_S", "K_S" };
    string randomCardDeck[CARDS] = {"-"};
    
    // Display the cards in order
    cout << "Cards in order: ";
    for (int i=0; i<52; i++)
    {
            cout << " " + cardDeck[i] + ",";
    }
    
    cout << endl << endl;
    
    // Randomize the cards
    for (int i=0; i<52; i++)
    {
        card_pick = GetRandomNumber(0,CARDS-i-1);
        randomCardDeck[i] = cardDeck[card_pick];
        cardDeck[card_pick] = "Z_Z";
        int count = BubbleSort(cardDeck, CARDS);
    }
    
    // show the randomization of the cards
    cout << "Cards randomized: \n";
    for (int i=0; i<52; i++)
    {
            cout << " " + randomCardDeck[i] + ",";
    }
   
    // Re-order the cards
    for (int i = 0; i < CARDS; i++){
        cardDeck[i] = randomCardDeck[i];
        int count = BubbleSort(cardDeck,CARDS);
    }

    // Show the cards re-ordered again
    cout << endl << endl;
    cout << "Ordered again: \n";
    for (int i=0; i<52; i++)
    {
            cout << " " + cardDeck[i] + ",";
    }
 
    cout << endl;
    return 0;
}
