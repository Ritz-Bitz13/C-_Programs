/* 
 * Martin Barber
 * File:   GetInput.h
 * Author: Clint MacDonald being used by Martin Barber
 * Title: Getting User input for either Integers or Doubles
 * Created on March 20, 2022, 6:55 p.m.
 */

#include <iostream>
#include <iomanip>
using namespace std;

 

#ifndef GETINPUT_H
#define GETINPUT_H

 

int GetAnInt() {
    bool isValidInt(string);    // function prototype
    bool notAnInt = true;       // assume it is NOT an integer at first
    string str;
    
    while (notAnInt) {
        try {
            cin.sync();
            cin >> str;     // accepts a STRING input
            if ( !isValidInt(str) ) throw str;
        }
        catch (string e) {
            cout << "Invalid Integer - Please re-enter a number between 1 & 365: ";
            continue;
        }
        notAnInt = false;
    }
    
    return atoi(str.c_str()) ;  // convert this string to an integer
    // Table 14.7 on page 650 of textbook
}

 

bool isValidInt(string str) {
    int start = 0;  // starting location when we go through the string
    int i, strLen;
    bool isValid = true;    // assume is valid to start
    bool hasSign = false;   // assume positive number ( no sign )
    
    strLen = int(str.length());
    
    // check for a zero length string
    if (strLen == 0) isValid = false;
    
    // check if there is a leading sign (- or +)
    if (str.at(0) == '-' || str.at(0) == '+') {
        hasSign = true;
        start = 1;
    }
    
    // check if there is a sign and nothing else
    if (hasSign && strLen == 1) isValid = false;
    
    
    // not iterate through the string to check if each digit is a number
    i = start;
    while (isValid && i < strLen) {
        if ( !isdigit(str.at(i)) ) isValid = false;
        i++;
    }
    
    return isValid;
}

 

double GetADbl() {
    bool isValidDbl(string);  // function prototype
    bool notADbl = true;
    string str;
    
    while (notADbl) {
        try {
            cin >> str;  // accept a string input
            if (!isValidDbl(str)) throw str;
        }
        catch (string e) {
            cout << "Invalid Number - Please re-enter: ";
            continue;
        }
        notADbl = false;
    }
    return atof(str.c_str()); // converts to an double 
    // Table 14.7 - Page 650 of textbook
}

 

bool isValidDbl(string str) {
    int start = 0, i, strLen;
    bool isValid = true;        // assume valid at first
    bool hasSign = false;       // assume positive number first (no - sign)
    bool hasDecimal = false;    // assume there is no decimal place
    strLen = int(str.length());
    
    // check for an empty string
    if (strLen == 0) isValid = false;
    
    // check for a leading sign
    if (str.at(0) == '-' || str.at(0) == '+') {
        hasSign = true;
        start = 1;  // skip the first character and check rest for integer status
    }
    
    // check there is one char after sign (if a sign exists)
    if (hasSign && strLen == 1) isValid = false;
    
    // now iterate through string for numeric values.
    i = start;  // set loop to start at character 0 or 1, based on hasSign

 

    while (isValid && i < strLen){
        if (str.at(i) == '.') {
            if (hasDecimal) isValid = false;
            hasDecimal = true;
        } 
        else {
            if (!isdigit(str.at(i))) isValid = false; 
        }
        i++;
    }
    
    return isValid;
}

 

#endif /* GETINPUT_H */