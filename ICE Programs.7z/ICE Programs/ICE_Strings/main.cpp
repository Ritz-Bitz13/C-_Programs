/** String_Intro.cpp
 *	
 *	String Example Program for OOP 2200. In this example, we will 
 *	create and use a create a  std::string. 
 *
 *   
 *	@author		Thom MacDonald
 *	@version	2018.02
 *	@since		11 Mar 2018
 *	@see 		Bronson, G. (2012).  Chapter 15 Strings as character arrays. 
 *					In A First Book of C++ (4th ed.). 
 *					Boston, MA: Course Technology.
 *	@see		<string> � C++ Reference. (n.d.). In Cplusplus.com. 
 *				   Retrieved 11 Mar 2018 from 
 *				   http://www.cplusplus.com/reference/string/
*/

#include <iostream>
#include <cstring> 
#include <string>
using namespace std;

int main()
{
	// Declarations
	
	string testString = "BLAGO!";  // resizes dynamically like a vector
	 	
	// Output an information header
	cout << "string Intro" << endl
		 << "============" << endl;
	
	// Output the string and key info about it.
	cout << "\nThe maximum size of a string is " << testString.max_size() << endl;
		 
	cout << "\"" <<  testString << "\" is using " << testString.length() << " of the " 
		 << testString.capacity() << " characters available." << endl << endl;

	// Output each character and its ACSII code, one-by-one.
	for(int index = 0; index <= testString.size(); index++) // boundary overflow
	{
		cout << "\t" << testString[index] << " : " << (int) testString[index] << endl;
	}

	// Assign a new string to the std::string.
	//testString = "chicken"; // will compile, we CAN assign to an std::string like this.
	
	// Output the string and key info about it.
	cout << "\n\n\"" <<  testString << "\" is using " << testString.length() << " of the " 
		 << testString.capacity() << " characters available." << endl;
		 
//	// Shrink capacity to size. strings and vectors are closely related.
	testString.shrink_to_fit(); 
//	
//	// Output the string and key info about it again.
	cout << "\nAfter shrinking, \"" <<  testString << "\" is using " << testString.length() << " of the " 
		 << testString.capacity() << " characters available." << endl;

	// end of program.			 
	cout << endl << endl;
	return 0;
}
	

