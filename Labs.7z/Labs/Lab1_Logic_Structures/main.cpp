//<editor-fold desc="Comment Header">
/* 
 * File:   main.cpp
 * Author: Martin Barber
 * Student ID: 100368442
 * Created on Feb 3rd, 2022, 6:14 p.m.
 * Purpose: OOP 2200 -- Week 04 Demo B
 * Definition: 
 */
//</editor-fold>

//<editor-fold desc="Inclusions and Global Variables">
#include <iostream>
#include <windows.h>
using namespace std;
HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
int scoreIn;
double averageScore;
double totalAverage;
int totalScore;
int colourPlayer = 1;

    
    
//</editor-fold>


/*
 * Main Application
 */
int main() {

    cout    << "---------------------------" << endl
            << "--- Archery Competition ---" << endl
            << "---------------------------" << endl;
    
    // Start first for loop to loop between the 3 players
    for (int player = 1; player <= 3; player++) 
    {
        // Set values to zero, for when the loop resets for the next player. The total score and average will be 0.
        totalScore = 0;
        averageScore = 0.0;
        
        // Start second loop to get each round scores for each player.
        for (int round=1; round<= 4; round++) 
        {
            // Reset the value so there is no possible number confusion
            scoreIn = 0;
            
            // Asks user to start entering the score
            cout << "Please enter the score ";
            // Changing font colour to identify easier
            SetConsoleTextAttribute(hConsole, colourPlayer);
            cout << "Archer "<< player << ""; 
            // Changing font colour to default
            SetConsoleTextAttribute(hConsole, 7);
            cout << " recieved in round " << round << ": ";
            cin >> scoreIn;

            // Checks if the input is a number and also if it is between 0 and 60.
            while (cin.fail() ||  scoreIn < 0 || scoreIn > 60){
                // Set text colour to red because of an error.
                SetConsoleTextAttribute(hConsole, 4);
                cin.clear();
                cin.sync();
                // Display error
                cout << "ERROR! You must type a number between 0 and 60. ";
                // Change text colour back to default
                SetConsoleTextAttribute(hConsole, 7);
                cout << "Please enter round " << round << " score: ";
                cin >> scoreIn;
            }

            // Once the check is complete add to the total average and the total score for the archer
            averageScore += scoreIn;
            totalScore += scoreIn;
        }
        // Adds 1 to the colourPlayer variable to change the colour of each player 
        // when typing in scores to show you're giving information to a new player.
        colourPlayer += 1;
        
        // Divider to separate the scores to the final result
        cout << "-------------------------------------------------------" << endl;
        // Sets the colour to the player number (1, 2 or 3)
        SetConsoleTextAttribute(hConsole, player);
                
        // Display the information: Give total results for the player and give the average (rounded to 2 decimal places)
        cout  << "Archer " << player << " Total score: " << totalScore << endl;
        cout  <<"Archer " << player << " Average score: " 
              << setiosflags(ios::fixed) // setiosflags(iso::fixed) will be the first qualifier to get amount of decimal places
              << setprecision(2) // This will set decimal places to 2
              << averageScore / 4 << endl;
        
        //Gets each players average score and adds them to the total average
        totalAverage += averageScore / 4;
        
        // Sets colour back to the standard white
        SetConsoleTextAttribute(hConsole, 7);
        cout << endl;
                
        
    }
    // Displays the average between all players
    SetConsoleTextAttribute(hConsole, 10);
    cout << "Average between all players: " << totalAverage / 3 << endl;
    cout << endl;
    // change text back to default colours
    SetConsoleTextAttribute(hConsole, 7);
    
    
    
    return 0;
}

