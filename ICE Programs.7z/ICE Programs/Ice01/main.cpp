
/* 
 * File:   main.cpp
 * Author: Martin Barber
 * Student ID: 10036844
 * Created on January 13, 2022, 7:45 p.m.
 * Purpose: OOP 2200 Week 1 - ICE 01
 */

#include <iostream>

using namespace std;

/*
 * This is the first ICE of the course learning the first few basics of writing a program
 */
int main() {

    cout << "Hello, Martin Barber" << endl;
    cout << "Student ID: 100368442" << endl;
    cout << "January 13th, 2022" << endl;
    cout << endl;
    
    
    return 0;
}

