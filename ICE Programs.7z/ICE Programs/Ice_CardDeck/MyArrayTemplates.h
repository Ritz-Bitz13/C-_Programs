/* 
 * File:   MyArrayTemplates.h
 * Author: Martin Barber
 *
 * Created on March 16, 2022, 7:38 p.m.
 */

#ifndef MYARRAYTEMPLATES_H
#define MYARRAYTEMPLATES_H



#endif /* MYARRAYTEMPLATES_H */

/** @File   MyArrayTemplates.h
 * @author Clint MacDonald
 * @credit Thom MacDonald
 * @since  March 10, 2021
 * @see    Bronson, G. (2012).  Chapter 7 Arrays. 
 *          In A First Book of C++ (4th ed.). 
 *          Boston, MA: Course Technology.
 * @see		Linear Search:  https://youtu.be/8XWgz1YKMtg
 * @see		Bubble Sort:    https://youtu.be/L__rzpaMGQM
 * @see		Selection Sort: https://youtu.be/JhMja0PwbwA
 * @see		Binary Search:  https://youtu.be/Y2U3xIhPJkU
 */

#ifndef MY_ARRAY_TEMPLATES
#define MY_ARRAY_TEMPLATES
using namespace std;

namespace MyArrayTemplates {
    
    /** LinearSearch function template
     * @param   sourceList[] - an input array of values to be searched
     * @param   SIZE - the size of the array being sent
     * @param   key - value that we are looking for
     * @return  the first position (index#) in which the key was found
     *              if not found will return -1
     */
    template <class T>
    int LinearSearch(T sourceList[], const int SIZE, T key) {
        int foundIndex = -1;
        
        // loop through the array to find the key value
        for (int i = 0; i < SIZE; i++) {
            // if the current element is the same as the key
            if (sourceList[i] == key) {
                foundIndex = i;
                exit;
            }
        }
        return foundIndex;
    }
        
    /** BinarySearch function template
     * @param   sourceList[] - an input array of values to be searched
     * @param   SIZE - the size of the array being sent
     * @param   key - value that we are looking for
     * @return  a position (index#) in which the key was found
     *              if not found will return -1
     * @note    ASSUMES the values in the array are sorted
     */
    template <class T>
    int BinarySearch(T sourceList[], const int SIZE, T key) {
        int left = 0;           // index of first element
        int right = SIZE -1;    // index of last element
        int midPoint;
        int foundIndex = -1;
        
        // as long as the left index <= right index
        // and we have not yet found the key
        while (foundIndex == -1 && left <= right) {
            midPoint = (left + right)/2;
            if (key == sourceList[midPoint]) foundIndex = midPoint;
            else if (key > sourceList[midPoint]) left = midPoint + 1;
            else right = midPoint - 1;
        }
        return foundIndex;
    }
    
    /** SELECTION SORT 
     	 *  Finds the index containing the lowest value in the array and swaps that 
	 *  element with the first element. Then it finds the next lowest and swaps 
	 *  with the second position. This repeats until the second last position 
	 *  of the array. 
	 *
	 * 	@param  arrayValues[] - an array of values to sort
	 * 	@param  SIZE - the size of the array as a const int
	 * 	@return the number of moves needed to sort the array
     */
    template <class T>
    int SelectionSort(T arrayValues[], const int SIZE) {
        int minIndex;   // the index of the lowest value in the sub-set
                        // of the array that is NOT sorted
        int moves = 0;  // counter of swaps
        
        // for each element in the array up to the second last ....
        for (int i = 0; i < (SIZE -1); i++) {
            // find the lowest value
            minIndex = i;
            // compare with the rest of the non-sorted array
            for (int nextIndex = i+1; nextIndex < SIZE; nextIndex++) {
                if (arrayValues[nextIndex] < arrayValues[minIndex]) minIndex = nextIndex;
            }
            
            // swap the lowest value for the leftmost one.
            if (arrayValues[minIndex] < arrayValues[i]) {
                // swap value
                T temp = arrayValues[i];
                arrayValues[i] = arrayValues[minIndex];
                arrayValues[minIndex] = temp;
                moves++;
            }
        }
        return moves;
    }
    
    /**	BubbleSort function template
     *	Compare neighbouring elements in array. Swap if required. Repeat 
     *	SIZE - 1 times throughout full array. 
     *
     * 	@param  arrayValues[] - an array of values to sort
     * 	@param  SIZE - the size of the array as a const int
     * 	@return the number of swaps needed to sort the array
    */
    template <class T>
    int BubbleSort(T arrayValues[], const int SIZE)
    {	
            int moves = 0;  // the number of moves needed to sort the array

            // Repeat SIZE -1 times...
            for (int repeat = 0; repeat < (SIZE - 1); repeat++)
            {
                    // for each element of the array starting with the second element...
                    for (int index = 1; index < SIZE; index++)
                    {
                    // if this element value is smaller than the one before it...
                            if (arrayValues[index] < arrayValues[index - 1])
                            {
                                    // swap them
                                    T temp = arrayValues[index];
                                    arrayValues[index] = arrayValues[index - 1];
                                    arrayValues[index - 1] = temp;
                                    moves++; // increase the moves counter
                            }	

            } // next index
    } // repeat	
            return moves; // the number of swaps we needed to make
    }
    
}

#endif /* end of file */

