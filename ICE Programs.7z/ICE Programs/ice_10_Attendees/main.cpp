/* 
 * File:   main.cpp
 * Author: Martin Barber
 * Student ID: 10036844
 * Created on March 31st, 2022, 6:25 p.m.
 * Purpose: OOP 2200 Week 11 ICE - Vectors
 */
/* 
 * File:   main.cpp
 * Author: Martin Barber
 *
 * Created on March 31, 2022, 6:54 p.m.
 */

#include <iostream>
#include <vector>
#include <iomanip>

using namespace std;

void AddAttendee(string, vector<string> &people);
void RemoveAttendee(string, vector<string> &people);
void DisplayAttendee( vector<string> &people);


void AddAttendee(string name, vector<string> &people){
    try{
        if(people.size() >= 5){
            throw out_of_range(name + " can not be added, the meeting is full");
            exit;
        }
        people.push_back(name);
        return;
    }
    catch (out_of_range  Problem){
        cout << "Error: " << Problem.what() << endl;
    }
}

void RemoveAttendee(string name, vector<string> &people){
    for (int i=0; i < people.size(); i++){
        if (people[i] == name){
            people.erase(people.begin() + (i-1));
            exit;
        }
    }
}

void DisplayAttendees(vector<string> &people){
    for (int i =0; i<people.size(); i++) {
        cout << "Attendee " << i+1 << ": " << people[i] << endl;
    }
}

/*
 * 
 */
int main() {
    
    vector<string> attendees;
    AddAttendee("Martin Barber", attendees);
    cout << "The number of attendees are: " << attendees.size() << endl;
    AddAttendee("Clint MacDonald", attendees);
    cout << "The number of attendees are: " << attendees.size() << endl;
    AddAttendee("Gillian Young", attendees);
    cout << "The number of attendees are: " << attendees.size() << endl;
    AddAttendee("Ann Heche", attendees);
    cout << "The number of attendees are: " << attendees.size() << endl;
    RemoveAttendee("Gillian Young", attendees);
    cout << "The number of attendees are: " << attendees.size() << endl;
    AddAttendee("Raj Patel", attendees);
    cout << "The number of attendees are: " << attendees.size() << endl;
    AddAttendee("Michael Johnston", attendees);
    cout << "The number of attendees are: " << attendees.size() << endl;
    AddAttendee("Sarah Dunn", attendees);
    cout << "The number of attendees are: " << attendees.size() << endl;
    
    cout << "The final attendees list is: " << endl;
    DisplayAttendees(attendees);
   

    return 0;
}
